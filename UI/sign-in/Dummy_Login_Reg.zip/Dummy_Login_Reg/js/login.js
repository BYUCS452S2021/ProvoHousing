document.getElementById("signin").onclick = function () {
    console.log("Logged in")
    window.location.replace("http://www.w3schools.com")
    //location.href = "listing_page.html";
};